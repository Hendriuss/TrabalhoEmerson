# SIME - Sistema de Monitoramento de Erros Industriais (MetalTech)

Plataformas: **Web (PHP)** e **Mobile (C# Xamarin.Forms)**, ambas usando o mesmo banco **MySQL na nuvem (freedb.tech)**.

## 1. Banco de dados
1. Crie a conta em https://freedb.tech e crie um banco (anote host, banco, usuário e senha)
2. No phpMyAdmin do freedb, execute `banco/schema.sql`

## 2. Web (PHP)
Requisitos: PHP 8+ com `pdo_mysql` (XAMPP já traz).
1. Copie `web/` para `htdocs/sime`
2. Edite `web/config.php` com os dados do freedb.tech
3. Acesse `http://localhost/sime/`

## 3. Mobile (Xamarin.Forms)
1. Visual Studio com a carga *Desenvolvimento móvel com .NET*
2. Crie projeto **Xamarin.Forms - Em branco** chamado `SIME`
3. Copie os arquivos de `mobile/` para o projeto compartilhado e apague `MainPage`
4. Instale o NuGet **MySqlConnector** (versão 2.x) no projeto compartilhado **e no projeto Android**
5. Edite `mobile/Db.cs` (`Cs`) com os dados do freedb.tech
6. Marque a permissão **INTERNET** no projeto Android e execute

## Usuários de teste
operador/123 (Operador) · supervisor/123 (Supervisor)

## Máquinas
tcnc01 Torno CNC · fcnc01 Fresadora CNC · cpr01 Cortadora Plasma

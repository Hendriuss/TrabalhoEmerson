using System;

namespace SIME
{
    public class Usuario { public int Id; public string Nome, Login, Perfil; }

    public class Maquina
    {
        public string Codigo, Descricao;
        public override string ToString() => $"{Codigo} - {Descricao}";
    }

    public class Ocorrencia
    {
        public int? Id;
        public string MaquinaCodigo, CodigoErro, Descricao;
        public DateTimeOffset DataHora;
        public int OperadorId;
        public string Resumo => $"{DataHora.ToLocalTime():dd/MM/yyyy HH:mm} | {MaquinaCodigo} | {CodigoErro}";
    }

    public static class Sessao { public static Usuario Atual; }
}

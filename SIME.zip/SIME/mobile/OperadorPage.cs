using System;
using System.Collections.Generic;
using System.Linq;
using Xamarin.Forms;

namespace SIME
{
    public class OperadorPage : ContentPage
    {
        Picker pckMaquina = new Picker { Title = "Selecione a máquina" };
        Entry entCodigo = new Entry { Placeholder = "Código do erro (ex.: E-204)" };
        Editor edtDescricao = new Editor { Placeholder = "Descrição da falha", HeightRequest = 100 };
        Label lblDataHora = new Label { FontAttributes = FontAttributes.Bold };
        ListView lista = new ListView { HeightRequest = 250 };
        List<Maquina> maquinas = new List<Maquina>();

        public OperadorPage()
        {
            Title = "Operador: " + Sessao.Atual.Nome;
            var btn = new Button { Text = "Registrar ocorrência", BackgroundColor = Color.FromHex("#1f3a5f"), TextColor = Color.White };
            btn.Clicked += Registrar;
            var sair = new Button { Text = "Sair" };
            sair.Clicked += (s, e) => { Sessao.Atual = null; Application.Current.MainPage = new NavigationPage(new LoginPage()); };

            Content = new ScrollView
            {
                Content = new StackLayout
                {
                    Padding = 20, Spacing = 10,
                    Children =
                    {
                        new Label { Text = "Registrar ocorrência", FontSize = 22, FontAttributes = FontAttributes.Bold },
                        pckMaquina, entCodigo, edtDescricao,
                        new Label { Text = "Data/hora (automática):" }, lblDataHora,
                        new Label { Text = "Operador: " + Sessao.Atual.Nome },
                        btn,
                        new Label { Text = "Meus últimos registros", FontAttributes = FontAttributes.Bold, Margin = new Thickness(0,15,0,0) },
                        lista, sair
                    }
                }
            };
            Device.StartTimer(TimeSpan.FromSeconds(1), () => { lblDataHora.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"); return true; });
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();
            try
            {
                maquinas = await Db.Maquinas();
                pckMaquina.ItemsSource = maquinas.Select(m => m.ToString()).ToList();
                await Atualizar();
            }
            catch (Exception ex) { await DisplayAlert("Erro", ex.Message, "OK"); }
        }

        async System.Threading.Tasks.Task Atualizar()
        {
            var minhas = await Db.OcorrenciasDoOperador(Sessao.Atual.Id);
            lista.ItemsSource = minhas.Select(o => o.Resumo).ToList();
        }

        async void Registrar(object sender, EventArgs e)
        {
            if (pckMaquina.SelectedIndex < 0 || string.IsNullOrWhiteSpace(entCodigo.Text) || string.IsNullOrWhiteSpace(edtDescricao.Text))
            { await DisplayAlert("Atenção", "Preencha máquina, código e descrição.", "OK"); return; }
            try
            {
                await Db.Registrar(new Ocorrencia
                {
                    MaquinaCodigo = maquinas[pckMaquina.SelectedIndex].Codigo,
                    CodigoErro = entCodigo.Text.Trim(),
                    Descricao = edtDescricao.Text.Trim(),
                    DataHora = DateTimeOffset.Now,
                    OperadorId = Sessao.Atual.Id
                });
                entCodigo.Text = ""; edtDescricao.Text = ""; pckMaquina.SelectedIndex = -1;
                await Atualizar();
                await DisplayAlert("Sucesso", "Ocorrência registrada!", "OK");
            }
            catch (Exception ex) { await DisplayAlert("Erro", ex.Message, "OK"); }
        }
    }
}

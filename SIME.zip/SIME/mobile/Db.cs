using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Threading.Tasks;
using MySqlConnector;

namespace SIME
{
    // Acesso direto ao MySQL do freedb.tech (mesma base usada pela versão web)
    public static class Db
    {
        // ====== CONFIGURE AQUI (dados do painel do freedb.tech) ======
        const string Cs = "Server=sql.freedb.tech;Port=3306;Database=SEU_BANCO;User ID=SEU_USUARIO;Password=SUA_SENHA;SslMode=None;ConnectionTimeout=15;";
        // =============================================================

        static async Task<List<T>> Query<T>(string sql, Func<DbDataReader, T> map, params (string, object)[] ps)
        {
            var lista = new List<T>();
            using (var con = new MySqlConnection(Cs))
            {
                await con.OpenAsync();
                using (var cmd = new MySqlCommand(sql, con))
                {
                    foreach (var (n, v) in ps) cmd.Parameters.AddWithValue(n, v);
                    using (var r = await cmd.ExecuteReaderAsync())
                        while (await r.ReadAsync()) lista.Add(map(r));
                }
            }
            return lista;
        }

        static Ocorrencia MapOc(DbDataReader r) => new Ocorrencia
        {
            Id = r.GetInt32(r.GetOrdinal("id")),
            MaquinaCodigo = r.GetString(r.GetOrdinal("maquina_codigo")),
            CodigoErro = r.GetString(r.GetOrdinal("codigo_erro")),
            Descricao = r.GetString(r.GetOrdinal("descricao")),
            DataHora = new DateTimeOffset(DateTime.SpecifyKind(r.GetDateTime(r.GetOrdinal("data_hora")), DateTimeKind.Local)),
            OperadorId = r.GetInt32(r.GetOrdinal("operador_id"))
        };

        public static async Task<Usuario> Login(string login, string senha)
        {
            var l = await Query("SELECT id,nome,login,perfil FROM usuarios WHERE login=@l AND senha=@s",
                r => new Usuario { Id = r.GetInt32(0), Nome = r.GetString(1), Login = r.GetString(2), Perfil = r.GetString(3) },
                ("@l", login), ("@s", senha));
            return l.Count == 1 ? l[0] : null;
        }

        public static Task<List<Maquina>> Maquinas() =>
            Query("SELECT codigo,descricao FROM maquinas ORDER BY codigo",
                  r => new Maquina { Codigo = r.GetString(0), Descricao = r.GetString(1) });

        public static Task<List<Ocorrencia>> Ocorrencias() =>
            Query("SELECT * FROM ocorrencias ORDER BY data_hora DESC", MapOc);

        public static Task<List<Ocorrencia>> OcorrenciasDoOperador(int id) =>
            Query("SELECT * FROM ocorrencias WHERE operador_id=@id ORDER BY data_hora DESC LIMIT 10", MapOc, ("@id", id));

        public static async Task Registrar(Ocorrencia o)
        {
            using (var con = new MySqlConnection(Cs))
            {
                await con.OpenAsync();
                using (var cmd = new MySqlCommand(
                    "INSERT INTO ocorrencias (maquina_codigo,codigo_erro,descricao,data_hora,operador_id) VALUES (@m,@c,@d,@h,@o)", con))
                {
                    cmd.Parameters.AddWithValue("@m", o.MaquinaCodigo);
                    cmd.Parameters.AddWithValue("@c", o.CodigoErro);
                    cmd.Parameters.AddWithValue("@d", o.Descricao);
                    cmd.Parameters.AddWithValue("@h", o.DataHora.LocalDateTime);
                    cmd.Parameters.AddWithValue("@o", o.OperadorId);
                    await cmd.ExecuteNonQueryAsync();
                }
            }
        }
    }
}

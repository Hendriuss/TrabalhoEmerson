<?php
require 'config.php';
$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $r = q('SELECT id,nome,login,perfil FROM usuarios WHERE login=? AND senha=?', [trim($_POST['login'] ?? ''), $_POST['senha'] ?? '']);
    } catch (Exception $e) { $r = []; $erro = 'Falha de conexão: ' . $e->getMessage(); }
    if (count($r) === 1) {
        $_SESSION['u'] = $r[0];
        header('Location: ' . ($_SESSION['u']['perfil'] === 'supervisor' ? 'dashboard.php' : 'operador.php'));
        exit;
    }
    if (!$erro) $erro = 'Login ou senha inválidos.';
}
cabecalho('Login'); ?>
<div style="display:flex;justify-content:center;align-items:center;min-height:calc(100vh - 200px)">
 <div class="card" style="max-width:400px;margin:60px auto;padding:40px;text-align:center">
  <h1 style="color:#1f3a5f;font-size:32px;margin-bottom:10px">SIME</h1>
  <p style="color:#666;margin-bottom:30px">Sistema de Monitoramento de Erros Industriais</p>
  <?php if ($erro): ?><div class="erro"><?= h($erro) ?></div><?php endif; ?>
  <form method="post">
    <label>Login</label><input name="login" required autofocus placeholder="Digite seu login">
    <label>Senha</label><input name="senha" type="password" required placeholder="Digite sua senha">
    <button style="width:100%;margin-top:25px">Entrar</button>
  </form>
  <p style="margin-top:20px;font-size:12px;color:#999">MetalTech Indústria Metalmecânica</p>
 </div>
</div>
<?php rodape();

<?php
// ====== CONFIGURE AQUI (dados do painel do freedb.tech) ======
const DB_HOST = 'sql.freedb.tech';
const DB_PORT = 3306;
const DB_NAME = 'freedb_ewch2pcF';
const DB_USER = 'u_oxNaFM';
const DB_PASS = '3tWMgeW8KEYN';
// =============================================================
date_default_timezone_set('America/Sao_Paulo');
session_start();

function db(): PDO {
    static $pdo = null;
    if (!$pdo) {
        $pdo = new PDO('mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
    }
    return $pdo;
}
// Executa SQL com parâmetros e devolve as linhas (SELECT) ou array vazio (INSERT)
function q(string $sql, array $p = []): array {
    $st = db()->prepare($sql);
    $st->execute($p);
    return $st->columnCount() ? $st->fetchAll() : [];
}

function exigir(string $perfil): void {
    if (empty($_SESSION['u']) || $_SESSION['u']['perfil'] !== $perfil) {
        header('Location: login.php'); exit;
    }
}
function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function cabecalho(string $titulo): void { ?>
<!DOCTYPE html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>SIME - <?= h($titulo) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
 *{box-sizing:border-box;margin:0;padding:0}
 body{font-family:'Inter',Arial,sans-serif;background:#f5f7fa;color:#1a1a2e;line-height:1.6}
 header{background:linear-gradient(135deg,#1f3a5f 0%,#2d5a87 100%);color:#fff;padding:20px 30px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 10px rgba(0,0,0,0.1)}
 header h1{font-size:24px;font-weight:700;letter-spacing:0.5px}
 header .user-info{display:flex;align-items:center;gap:15px;font-size:14px}
 header a{color:#ffd166;text-decoration:none;font-weight:500;padding:8px 16px;background:rgba(255,255,255,0.1);border-radius:20px;transition:all 0.3s}
 header a:hover{background:rgba(255,255,255,0.2)}
 main{max-width:1200px;margin:30px auto;padding:0 20px}
 .card{background:#fff;border-radius:12px;padding:25px;margin-bottom:25px;box-shadow:0 2px 8px rgba(0,0,0,0.08)}
 .card h2{color:#1f3a5f;font-size:20px;margin-bottom:20px;font-weight:600}
 .card h3{color:#2d5a87;font-size:16px;margin-bottom:15px;font-weight:600}
 label{display:block;margin-top:15px;font-weight:500;color:#444;font-size:14px}
 input,select,textarea{width:100%;padding:12px;margin-top:6px;box-sizing:border-box;border:2px solid #e0e0e0;border-radius:8px;font-size:14px;font-family:'Inter',Arial,sans-serif;transition:border-color 0.3s}
 input:focus,select:focus,textarea:focus{outline:none;border-color:#1f3a5f}
 button{background:linear-gradient(135deg,#1f3a5f 0%,#2d5a87 100%);color:#fff;border:0;padding:12px 28px;border-radius:8px;margin-top:20px;cursor:pointer;font-size:14px;font-weight:600;transition:transform 0.2s,box-shadow 0.2s}
 button:hover{transform:translateY(-2px);box-shadow:0 4px 12px rgba(31,58,95,0.3)}
 table{width:100%;border-collapse:collapse;margin-top:15px}
 th{background:#f8f9fa;color:#1f3a5f;font-weight:600;padding:12px;text-align:left;font-size:13px;text-transform:uppercase;letter-spacing:0.5px}
 td{padding:12px;border-bottom:1px solid #e8e8e8;font-size:14px;color:#333}
 tr:hover{background:#f8f9fa}
 .ok{background:#d4edda;color:#155724;padding:12px;border-radius:8px;font-weight:500;margin-bottom:15px}
 .erro{background:#f8d7da;color:#721c24;padding:12px;border-radius:8px;font-weight:500;margin-bottom:15px}
 .filtros{display:flex;gap:15px}.filtros>div{flex:1}
 .kpi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:20px;margin-bottom:25px}
 .kpi-card{background:linear-gradient(135deg,#1f3a5f 0%,#2d5a87 100%);color:#fff;padding:25px;border-radius:16px;text-align:center;box-shadow:0 8px 20px rgba(0,0,0,0.15);transition:transform 0.3s,box-shadow 0.3s}
 .kpi-card:hover{transform:translateY(-5px);box-shadow:0 12px 30px rgba(0,0,0,0.2)}
 .kpi-card .kpi-icon{font-size:32px;margin-bottom:10px}
 .kpi-card .value{font-size:36px;font-weight:700;margin:10px 0}
 .kpi-card .label{font-size:13px;opacity:0.95;font-weight:500}
 .status-pendente{background:#ff9f43;color:#fff;padding:4px 12px;border-radius:12px;font-size:12px;font-weight:600;display:inline-block}
 .status-resolvida{background:#2ecc71;color:#fff;padding:4px 12px;border-radius:12px;font-size:12px;font-weight:600;display:inline-block}
 .btn-resolver{background:linear-gradient(135deg,#43e97b 0%,#38f9d7 100%);color:#fff;padding:6px 16px;border-radius:6px;text-decoration:none;font-size:12px;font-weight:600;display:inline-block;transition:transform 0.2s}
 .btn-resolver:hover{transform:scale(1.05)}
</style></head><body>
<header>
 <h1>SIME — MetalTech</h1>
 <div class="user-info">
  <span><?= h($_SESSION['u']['nome'] ?? '') ?></span>
  <span style="background:rgba(255,209,102,0.2);padding:4px 12px;border-radius:15px;font-size:12px"><?= h($_SESSION['u']['perfil'] ?? '') ?></span>
  <a href="logout.php">Sair</a>
 </div>
</header><main>
<?php }
function rodape(): void { echo '</main></body></html>'; }

<?php
require 'config.php';
exigir('supervisor');
$todas = q('SELECT o.*, u.nome AS operador FROM ocorrencias o JOIN usuarios u ON u.id=o.operador_id ORDER BY o.data_hora DESC');

// Agrupamento mensal e por máquina
$porMes = []; $porMaq = []; $porErro = []; $porDia = [];
foreach ($todas as $o) {
    $mes = date('Y-m', strtotime($o['data_hora']));
    $dia = date('Y-m-d', strtotime($o['data_hora']));
    $porMes[$mes] = ($porMes[$mes] ?? 0) + 1;
    $porMaq[$o['maquina_codigo']] = ($porMaq[$o['maquina_codigo']] ?? 0) + 1;
    $porErro[$o['codigo_erro']] = ($porErro[$o['codigo_erro']] ?? 0) + 1;
    $porDia[$dia] = ($porDia[$dia] ?? 0) + 1;
}
ksort($porMes); arsort($porMaq); arsort($porErro); ksort($porDia);

// Dados dos últimos 7 dias
$ultimos7Dias = [];
for ($i = 6; $i >= 0; $i--) {
    $data = date('Y-m-d', strtotime("-$i days"));
    $ultimos7Dias[$data] = $porDia[$data] ?? 0;
}
$labels7Dias = array_map(function($d) {
    return date('d/m', strtotime($d));
}, array_keys($ultimos7Dias));

// Últimos 6 meses (inclui meses sem ocorrência)
$nomesMes = ['01'=>'Jan','02'=>'Fev','03'=>'Mar','04'=>'Abr','05'=>'Mai','06'=>'Jun','07'=>'Jul','08'=>'Ago','09'=>'Set','10'=>'Out','11'=>'Nov','12'=>'Dez'];
$ultimos6Meses = []; $labels6Meses = [];
for ($i = 5; $i >= 0; $i--) {
    $ref = date('Y-m', strtotime(date('Y-m-01') . " -$i months"));
    $ultimos6Meses[$ref] = $porMes[$ref] ?? 0;
    $labels6Meses[] = $nomesMes[substr($ref, 5, 2)] . '/' . substr($ref, 2, 2);
}

// Cálculos de novos KPIs
$pendentes = array_filter($todas, fn($o) => ($o['status'] ?? 'pendente') === 'pendente');
$resolvidas = array_filter($todas, fn($o) => ($o['status'] ?? 'pendente') === 'resolvida');

// Filtros da tabela
$fstatus = $_GET['status'] ?? '';
$lista = array_filter($todas, fn($o) =>
    ($fstatus === '' || ($o['status'] ?? 'pendente') === $fstatus));

cabecalho('Dashboard'); ?>
<div style="text-align:right;margin-bottom:15px;color:#666;font-size:13px">
  🕒 Última atualização: <span id="ultimaAtualizacao"><?= date('d/m/Y H:i:s') ?></span>
</div>
<div class="kpi-grid">
 <div class="kpi-card" style="background:linear-gradient(135deg,#1f3a5f 0%,#2d5a87 100%)">
  <div class="kpi-icon">📊</div>
  <div class="label">Total de Ocorrências</div>
  <div class="value"><?= count($todas) ?></div>
 </div>
 <div class="kpi-card" style="background:linear-gradient(135deg,#dc3545 0%,#c82333 100%)">
  <div class="kpi-icon">⚠️</div>
  <div class="label">Máquina Mais Crítica</div>
  <div class="value" style="font-size:24px"><?= $porMaq ? h(array_key_first($porMaq)) : '-' ?></div>
  <div style="font-size:12px;opacity:0.8"><?= $porMaq ? reset($porMaq) . ' erros' : '-' ?></div>
 </div>
 <div class="kpi-card" style="background:linear-gradient(135deg,#6c757d 0%,#495057 100%)">
  <div class="kpi-icon">🔥</div>
  <div class="label">Erro Mais Comum</div>
  <div class="value" style="font-size:24px"><?= $porErro ? h(array_key_first($porErro)) : '-' ?></div>
  <div style="font-size:12px;opacity:0.8"><?= $porErro ? reset($porErro) . ' ocorrências' : '-' ?></div>
 </div>
 <div class="kpi-card" style="background:linear-gradient(135deg,#f59e0b 0%,#d97706 100%)">
  <div class="kpi-icon">⏳</div>
  <div class="label">Ocorrências Pendentes</div>
  <div class="value"><?= count($pendentes) ?></div>
  <div style="font-size:12px;opacity:0.8">aguardando resolução</div>
 </div>
 <div class="kpi-card" style="background:linear-gradient(135deg,#28a745 0%,#1e7e34 100%)">
  <div class="kpi-icon">✅</div>
  <div class="label">Ocorrências Resolvidas</div>
  <div class="value"><?= count($resolvidas) ?></div>
  <div style="font-size:12px;opacity:0.8">já concluídas</div>
 </div>
</div>
<div class="card"><h2>📅 Erros por Dia (Últimos 7 dias)</h2><canvas id="g7Dias" height="100"></canvas></div>
<div class="card"><h2>📊 Erros por Mês (Últimos 6 meses)</h2><canvas id="gMes" height="100"></canvas></div>
<div class="card"><h2>Ocorrências</h2>
  <form method="get" class="filtros" style="max-width:300px">
    <div><label>Status</label>
    <select name="status" onchange="this.form.submit()">
      <option value="">Todos</option>
      <option value="pendente" <?= $fstatus === 'pendente' ? 'selected' : '' ?>>Pendente</option>
      <option value="resolvida" <?= $fstatus === 'resolvida' ? 'selected' : '' ?>>Resolvida</option>
    </select></div>
  </form><br>
  <table><tr><th>Data/Hora</th><th>Máquina</th><th>Código</th><th>Descrição</th><th>Operador</th><th>Status</th><th>Ação</th></tr>
  <?php foreach ($lista as $o):
    $status = $o['status'] ?? 'pendente';
    $badgeClass = $status === 'resolvida' ? 'status-resolvida' : 'status-pendente';
  ?>
    <tr><td><?= date('d/m/Y H:i', strtotime($o['data_hora'])) ?></td><td><?= h($o['maquina_codigo']) ?></td>
    <td><?= h($o['codigo_erro']) ?></td><td><?= h($o['descricao']) ?></td><td><?= h($o['operador']) ?></td>
    <td><span class="<?= $badgeClass ?>"><?= ucfirst($status) ?></span></td>
    <td style="white-space:nowrap">
      <?php if ($status === 'pendente'): ?>
        <a href="resolver.php?id=<?= $o['id'] ?>" class="btn-resolver">🔧 Resolver</a>
      <?php else: ?>
        <span style="color:#999;font-size:12px">✅ Concluída</span>
      <?php endif; ?>
      <?php if ($status === 'pendente'): ?>
        <a href="deletar.php?id=<?= $o['id'] ?>" style="background:#dc3545;color:#fff;padding:6px 16px;border-radius:6px;text-decoration:none;font-size:12px;font-weight:600;display:inline-block;margin-left:6px">🗑️ Deletar</a>
      <?php endif; ?>
    </td></tr>
  <?php endforeach; ?></table>
</div>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>

new Chart(document.getElementById('g7Dias'), {
  type: 'bar',
  data: {
    labels: <?= json_encode($labels7Dias) ?>,
    datasets: [{ label: 'Erros no dia', data: <?= json_encode(array_values($ultimos7Dias)) ?>,
      backgroundColor: '#2d5a87', borderRadius: 6 }]
  },
  options: {
    scales: { y: { beginAtZero: true, ticks: { precision: 0 } }, x: { grid: { display: false } } },
    plugins: { legend: { display: false } }
  }
});

new Chart(document.getElementById('gMes'), {
  type: 'bar',
  data: {
    labels: <?= json_encode($labels6Meses) ?>,
    datasets: [{ label: 'Erros no mês', data: <?= json_encode(array_values($ultimos6Meses)) ?>,
      backgroundColor: '#2d5a87', borderRadius: 6 }]
  },
  options: {
    scales: { y: { beginAtZero: true, ticks: { precision: 0 } }, x: { grid: { display: false } } },
    plugins: { legend: { display: false } }
  }
});

// Recarrega a página a cada 10 segundos (mantém o filtro de status)
setTimeout(function () { location.reload(); }, 10000);
</script>
<?php rodape();
<?php
require 'config.php';
exigir('supervisor');

$id = $_GET['id'] ?? 0;
$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        q('UPDATE ocorrencias SET status=?, data_resolucao=NOW(), resolvido_por=? WHERE id=?',
            ['resolvida', $_SESSION['u']['id'], $id]);
        header('Location: dashboard.php?sucesso=1');
        exit;
    } catch (Exception $e) {
        $erro = 'Erro ao resolver: ' . $e->getMessage();
    }
}

$ocorrencia = q('SELECT o.*, u.nome AS operador FROM ocorrencias o JOIN usuarios u ON u.id=o.operador_id WHERE o.id=?', [$id]);

if (count($ocorrencia) === 0) {
    header('Location: dashboard.php');
    exit;
}

$oc = $ocorrencia[0];

cabecalho('Resolver Ocorrência'); ?>
<div class="card" style="max-width:600px;margin:0 auto">
 <h2>🔧 Resolver Ocorrência</h2>
 <?php if ($erro): ?><div class="erro"><?= h($erro) ?></div><?php endif; ?>

 <div style="background:#f8f9fa;padding:20px;border-radius:8px;margin-bottom:20px">
  <p><strong>Máquina:</strong> <?= h($oc['maquina_codigo']) ?></p>
  <p><strong>Código do Erro:</strong> <?= h($oc['codigo_erro']) ?></p>
  <p><strong>Descrição:</strong> <?= h($oc['descricao']) ?></p>
  <p><strong>Data/Hora:</strong> <?= date('d/m/Y H:i', strtotime($oc['data_hora'])) ?></p>
  <p><strong>Operador:</strong> <?= h($oc['operador']) ?></p>
 </div>

 <form method="post">
  <p style="margin-bottom:20px;color:#666">Tem certeza que deseja marcar esta ocorrência como resolvida?</p>
  <button type="submit" style="background:linear-gradient(135deg,#43e97b 0%,#38f9d7 100%)">✅ Confirmar Resolução</button>
  <a href="dashboard.php" style="display:inline-block;margin-left:10px;padding:12px 28px;background:#e0e0e0;color:#333;text-decoration:none;border-radius:8px;font-weight:600">Cancelar</a>
 </form>
</div>
<?php rodape();

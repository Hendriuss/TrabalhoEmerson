<?php
require 'config.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'login':
            $r = q('SELECT id,nome,login,perfil FROM usuarios WHERE login=? AND senha=?',
                [$_POST['login'] ?? '', $_POST['senha'] ?? '']);
            echo json_encode(count($r) === 1 ? $r[0] : null);
            break;

        case 'maquinas':
            echo json_encode(q('SELECT codigo,descricao FROM maquinas ORDER BY codigo'));
            break;

        case 'ocorrencias':
            $filtro = $_GET['filtro'] ?? 'todas';
            if ($filtro === 'operador') {
                echo json_encode(q('SELECT * FROM ocorrencias WHERE operador_id=? ORDER BY data_hora DESC LIMIT 10',
                    [$_POST['operador_id'] ?? 0]));
            } else {
                echo json_encode(q('SELECT o.*, u.nome AS operador FROM ocorrencias o JOIN usuarios u ON u.id=o.operador_id ORDER BY o.data_hora DESC'));
            }
            break;

        case 'registrar':
            q('INSERT INTO ocorrencias (maquina_codigo,codigo_erro,descricao,data_hora,operador_id) VALUES (?,?,?,?,?)', [
                $_POST['maquina'], $_POST['codigo_erro'], $_POST['descricao'],
                date('Y-m-d H:i:s'), $_POST['operador_id']
            ]);
            echo json_encode(['sucesso' => true]);
            break;

        default:
            echo json_encode(['erro' => 'Ação inválida']);
    }
} catch (Exception $e) {
    echo json_encode(['erro' => $e->getMessage()]);
}

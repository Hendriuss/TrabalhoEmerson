<?php
require 'config.php';
exigir('supervisor');

$id = (int)($_GET['id'] ?? 0);
$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        q("DELETE FROM ocorrencias WHERE id=? AND (status IS NULL OR status<>'resolvida')", [$id]);
        header('Location: dashboard.php?deletada=1');
        exit;
    } catch (Exception $e) {
        $erro = 'Erro ao deletar: ' . $e->getMessage();
    }
}

$ocorrencia = q('SELECT o.*, u.nome AS operador FROM ocorrencias o JOIN usuarios u ON u.id=o.operador_id WHERE o.id=?', [$id]);
if (count($ocorrencia) === 0) {
    header('Location: dashboard.php');
    exit;
}
$oc = $ocorrencia[0];
if (($oc['status'] ?? 'pendente') === 'resolvida') {
    header('Location: dashboard.php');
    exit;
}

cabecalho('Deletar Ocorrência'); ?>
<div class="card" style="max-width:600px;margin:0 auto">
 <h2>🗑️ Deletar Ocorrência</h2>
 <?php if ($erro): ?><div class="erro"><?= h($erro) ?></div><?php endif; ?>

 <div style="background:#f8f9fa;padding:20px;border-radius:8px;margin-bottom:20px">
  <p><strong>Máquina:</strong> <?= h($oc['maquina_codigo']) ?></p>
  <p><strong>Código do Erro:</strong> <?= h($oc['codigo_erro']) ?></p>
  <p><strong>Descrição:</strong> <?= h($oc['descricao']) ?></p>
  <p><strong>Data/Hora:</strong> <?= date('d/m/Y H:i', strtotime($oc['data_hora'])) ?></p>
  <p><strong>Operador:</strong> <?= h($oc['operador']) ?></p>
 </div>

 <form method="post">
  <p style="margin-bottom:20px;color:#721c24"><strong>Atenção:</strong> esta ação não pode ser desfeita. Deseja realmente deletar esta ocorrência?</p>
  <button type="submit" style="background:#dc3545">🗑️ Confirmar Exclusão</button>
  <a href="dashboard.php" style="display:inline-block;margin-left:10px;padding:12px 28px;background:#e0e0e0;color:#333;text-decoration:none;border-radius:8px;font-weight:600">Cancelar</a>
 </form>
</div>
<?php rodape();
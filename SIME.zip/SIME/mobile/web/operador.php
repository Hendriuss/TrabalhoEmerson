<?php
require 'config.php';
exigir('operador');
$msg = ''; $ok = true;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        q('INSERT INTO ocorrencias (maquina_codigo,codigo_erro,descricao,data_hora,operador_id) VALUES (?,?,?,?,?)', [
            $_POST['maquina'], trim($_POST['codigo_erro']), trim($_POST['descricao']),
            date('Y-m-d H:i:s'),            // data/hora exata
            $_SESSION['u']['id'],           // operador logado
        ]);
        $msg = 'Ocorrência registrada com sucesso!';
    } catch (Exception $e) { $ok = false; $msg = 'Erro ao registrar: ' . $e->getMessage(); }
}
$maquinas = q('SELECT * FROM maquinas ORDER BY codigo');
$minhas = q('SELECT o.*, u.nome AS resolvido_por_nome FROM ocorrencias o LEFT JOIN usuarios u ON u.id=o.resolvido_por WHERE o.operador_id=? ORDER BY o.data_hora DESC LIMIT 10', [$_SESSION['u']['id']]);

// KPIs do operador
$todasMinhas = q('SELECT * FROM ocorrencias WHERE operador_id=?', [$_SESSION['u']['id']]);
$pendentes = array_filter($todasMinhas, fn($o) => ($o['status'] ?? 'pendente') === 'pendente');
$resolvidas = array_filter($todasMinhas, fn($o) => ($o['status'] ?? 'pendente') === 'resolvida');
cabecalho('Operador'); ?>
<div class="kpi-grid">
 <div class="kpi-card" style="background:linear-gradient(135deg,#667eea 0%,#764ba2 100%)">
  <div class="kpi-icon">📊</div>
  <div class="label">Meus Registros</div>
  <div class="value"><?= count($todasMinhas) ?></div>
 </div>
 <div class="kpi-card" style="background:linear-gradient(135deg,#ff9f43 0%,#ff6b6b 100%)">
  <div class="kpi-icon">⏳</div>
  <div class="label">Pendentes</div>
  <div class="value"><?= count($pendentes) ?></div>
  <div style="font-size:12px;opacity:0.8">aguardando resolução</div>
 </div>
 <div class="kpi-card" style="background:linear-gradient(135deg,#2ecc71 0%,#27ae60 100%)">
  <div class="kpi-icon">✅</div>
  <div class="label">Resolvidos</div>
  <div class="value"><?= count($resolvidas) ?></div>
  <div style="font-size:12px;opacity:0.8">já concluídos</div>
 </div>
</div>
<div class="card">
  <h2>Registrar Ocorrência</h2>
  <p style="color:#666;margin-bottom:20px;font-size:14px">Operador: <strong><?= h($_SESSION['u']['nome']) ?></strong></p>
  <?php if ($msg): ?><div class="<?= $ok ? 'ok' : 'erro' ?>"><?= h($msg) ?></div><?php endif; ?>
  <form method="post">
    <label>Máquina</label>
    <select name="maquina" required>
      <?php foreach ($maquinas as $m): ?>
        <option value="<?= h($m['codigo']) ?>"><?= h($m['codigo']) ?> — <?= h($m['descricao']) ?></option>
      <?php endforeach; ?>
    </select>
    <label>Código do erro</label><input name="codigo_erro" required placeholder="Ex.: E-204">
    <label>Descrição da falha</label><textarea name="descricao" rows="3" required placeholder="Descreva detalhadamente a falha..."></textarea>
    <div style="background:#f8f9fa;padding:12px;border-radius:8px;margin-top:15px;font-size:13px;color:#666">
     <strong>Data/Hora:</strong> Será registrada automaticamente no momento do envio
    </div>
    <button>Registrar Ocorrência</button>
  </form>
</div>
<div class="card">
  <h2>Meus Últimos Registros</h2>
  <table><tr><th>Data/Hora</th><th>Máquina</th><th>Código</th><th>Descrição</th><th>Status</th><th>Resolvido por</th></tr>
  <?php foreach ($minhas as $o):
    $status = $o['status'] ?? 'pendente';
    $badgeClass = $status === 'resolvida' ? 'status-resolvida' : 'status-pendente';
  ?>
    <tr><td><?= date('d/m/Y H:i', strtotime($o['data_hora'])) ?></td><td><?= h($o['maquina_codigo']) ?></td>
    <td><?= h($o['codigo_erro']) ?></td><td><?= h($o['descricao']) ?></td>
    <td><span class="<?= $badgeClass ?>"><?= ucfirst($status) ?></span></td>
    <td>
      <?php if ($status === 'resolvida'): ?>
        <div style="font-size:12px">
          <strong><?= h($o['resolvido_por_nome']) ?></strong><br>
          <span style="color:#666"><?= date('d/m/Y H:i', strtotime($o['data_resolucao'])) ?></span>
        </div>
      <?php else: ?>
        <span style="color:#999;font-size:12px">—</span>
      <?php endif; ?>
    </td></tr>
  <?php endforeach; ?></table>
</div>
<?php rodape();

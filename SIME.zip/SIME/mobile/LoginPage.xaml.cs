using System;
using Xamarin.Forms;

namespace SIME
{
    public partial class LoginPage : ContentPage
    {
        public LoginPage() { InitializeComponent(); }

        async void Entrar_Clicked(object sender, EventArgs e)
        {
            Carregando.IsRunning = true; BtnEntrar.IsEnabled = false;
            try
            {
                var u = await Db.Login(EntLogin.Text?.Trim() ?? "", EntSenha.Text ?? "");
                if (u == null) { await DisplayAlert("Erro", "Login ou senha inválidos.", "OK"); return; }
                Sessao.Atual = u;
                Page destino = u.Perfil == "supervisor" ? (Page)new DashboardPage() : new OperadorPage();
                Application.Current.MainPage = new NavigationPage(destino)
                { BarBackgroundColor = Color.FromHex("#1f3a5f"), BarTextColor = Color.White };
            }
            catch (Exception ex) { await DisplayAlert("Falha de conexão", ex.Message, "OK"); }
            finally { Carregando.IsRunning = false; BtnEntrar.IsEnabled = true; }
        }
    }
}

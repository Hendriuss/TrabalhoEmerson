using System;
using Xamarin.Forms;

namespace AppMetalTech
{
    public partial class LoginPage : ContentPage
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        void Entrar_Clicked(object sender, EventArgs e)
        {
            var login = EntLogin.Text?.Trim() ?? "";
            var senha = EntSenha.Text ?? "";

            var usuario = Db.LoginStatico(login, senha);

            if (usuario == null)
            {
                DisplayAlert("Erro", "Login ou senha inválidos.", "OK");
                return;
            }

            Sessao.Atual = usuario;

            if (usuario.Perfil == "supervisor")
            {
                Application.Current.MainPage = new NavigationPage(new SupervisorPage())
                {
                    BarBackgroundColor = Color.FromHex("#1f3a5f"),
                    BarTextColor = Color.White
                };
            }
            else
            {
                Application.Current.MainPage = new NavigationPage(new OperadorPage())
                {
                    BarBackgroundColor = Color.FromHex("#1f3a5f"),
                    BarTextColor = Color.White
                };
            }
        }
    }
}

using System;

namespace AppMetalTech
{
    public class Usuario
    {
        public string Id { get; set; }
        public string Nome { get; set; }
        public string Login { get; set; }
        public string Perfil { get; set; }
    }

    public class Maquina
    {
        public string Codigo { get; set; }
        public string Descricao { get; set; }

        public override string ToString() => $"{Codigo} - {Descricao}";
    }

    public class Ocorrencia
    {
        public string Id { get; set; }
        public string MaquinaCodigo { get; set; }
        public string CodigoErro { get; set; }
        public string Descricao { get; set; }
        public string DataHora { get; set; }
        public string OperadorId { get; set; }
        public string OperadorNome { get; set; }
        public string Status { get; set; }
        public string DataResolucao { get; set; }
        public string ResolvidoPorNome { get; set; }

        public string Resumo
        {
            get
            {
                if (string.IsNullOrEmpty(DataHora))
                    return $"{MaquinaCodigo} | {CodigoErro}";
                try
                {
                    var dt = DateTime.Parse(DataHora);
                    return $"{dt:dd/MM/yyyy HH:mm} | {MaquinaCodigo} | {CodigoErro}";
                }
                catch
                {
                    return $"{MaquinaCodigo} | {CodigoErro}";
                }
            }
        }

        public string StatusFormatado
        {
            get
            {
                var s = Status ?? "pendente";
                return char.ToUpper(s[0]) + s.Substring(1);
            }
        }
    }

    public static class Sessao
    {
        public static Usuario Atual;
    }
}

using System;
using System.Collections.Generic;
using System.Linq;
using Xamarin.Forms;

namespace AppMetalTech
{
    public partial class OperadorPage : ContentPage
    {
        List<Maquina> maquinas = new List<Maquina>();
        List<Ocorrencia> minhasOcorrencias = new List<Ocorrencia>();

        public OperadorPage()
        {
            InitializeComponent();
            LblOperador.Text = "Operador: " + (Sessao.Atual?.Nome ?? "Não identificado");
            AtualizarDataHora();
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();
            maquinas = await Db.Maquinas();
            PckMaquina.ItemsSource = maquinas.Select(m => m.ToString()).ToList();
            await CarregarOcorrencias();
        }

        void AtualizarDataHora()
        {
            LblDataHora.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
            Device.StartTimer(TimeSpan.FromSeconds(1), () =>
            {
                LblDataHora.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
                return true;
            });
        }

        async void Registrar_Clicked(object sender, EventArgs e)
        {
            if (PckMaquina.SelectedIndex < 0)
            {
                await DisplayAlert("Atenção", "Selecione a máquina.", "OK");
                return;
            }
            if (string.IsNullOrWhiteSpace(EntCodigo.Text))
            {
                await DisplayAlert("Atenção", "Informe o código do erro.", "OK");
                return;
            }
            if (string.IsNullOrWhiteSpace(EdtDescricao.Text))
            {
                await DisplayAlert("Atenção", "Informe a descrição da falha.", "OK");
                return;
            }

            try
            {
                var ocorrencia = new Ocorrencia
                {
                    MaquinaCodigo = maquinas[PckMaquina.SelectedIndex].Codigo,
                    CodigoErro = EntCodigo.Text.Trim(),
                    Descricao = EdtDescricao.Text.Trim(),
                    DataHora = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                    OperadorId = Sessao.Atual?.Id ?? "0",
                    Status = "pendente"
                };

                await Db.Registrar(ocorrencia);

                EntCodigo.Text = "";
                EdtDescricao.Text = "";
                PckMaquina.SelectedIndex = -1;

                await CarregarOcorrencias();
                await DisplayAlert("Sucesso", "Ocorrência registrada!", "OK");
            }
            catch (Exception ex)
            {
                await DisplayAlert("Erro", ex.Message, "OK");
            }
        }

        async System.Threading.Tasks.Task CarregarOcorrencias()
        {
            if (Sessao.Atual == null) return;

            try
            {
                int operadorId;
                if (int.TryParse(Sessao.Atual.Id, out operadorId))
                {
                    minhasOcorrencias = await Db.OcorrenciasDoOperador(operadorId);

                    // Atualizar KPIs
                    LblTotal.Text = minhasOcorrencias.Count.ToString();
                    var pendentes = minhasOcorrencias.Where(o => (o.Status ?? "pendente") == "pendente").Count();
                    var resolvidas = minhasOcorrencias.Where(o => (o.Status ?? "pendente") == "resolvida").Count();
                    LblPendentes.Text = pendentes.ToString();
                    LblResolvidos.Text = resolvidas.ToString();

                    // Lista formatada
                    ListaOcorrencias.ItemsSource = minhasOcorrencias.Select(o => new
                    {
                        Resumo = o.Resumo,
                        Descricao = o.Descricao,
                        Status = o.StatusFormatado,
                        ResolvidoPor = string.IsNullOrEmpty(o.ResolvidoPorNome) ? "" : $"Resolvido por: {o.ResolvidoPorNome}"
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Erro", ex.Message, "OK");
            }
        }

        void Sair_Clicked(object sender, EventArgs e)
        {
            Sessao.Atual = null;
            Application.Current.MainPage = new NavigationPage(new LoginPage())
            {
                BarBackgroundColor = Color.FromHex("#1f3a5f"),
                BarTextColor = Color.White
            };
        }
    }
}

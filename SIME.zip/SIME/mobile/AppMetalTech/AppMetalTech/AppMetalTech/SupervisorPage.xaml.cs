using System;
using System.Collections.Generic;
using System.Linq;
using Xamarin.Forms;

namespace AppMetalTech
{
    public partial class SupervisorPage : ContentPage
    {
        List<Ocorrencia> todas = new List<Ocorrencia>();

        public SupervisorPage()
        {
            InitializeComponent();
            LblSupervisor.Text = "Supervisor: " + (Sessao.Atual?.Nome ?? "Não identificado");
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();
            await CarregarDados();
        }

        async System.Threading.Tasks.Task CarregarDados()
        {
            try
            {
                todas = await Db.Ocorrencias();

                // KPI Total
                LblTotal.Text = todas.Count.ToString();

                if (todas.Count == 0)
                {
                    GraficoMeses.Children.Clear();
                    ListaOcorrencias.ItemsSource = new List<string> { "Nenhuma ocorrência registrada" };
                    LblMaquinaCritica.Text = "-";
                    LblMediaDiaria.Text = "0";
                    LblTendencia.Text = "-";
                    LblErroComum.Text = "0";
                    LblPendentes.Text = "0";
                    return;
                }

                // KPIs como no web
                var porMaquina = todas.GroupBy(o => o.MaquinaCodigo)
                                       .ToDictionary(g => g.Key, g => g.Count())
                                       .OrderByDescending(g => g.Value);

                var porErro = todas.GroupBy(o => o.CodigoErro)
                                   .ToDictionary(g => g.Key, g => g.Count())
                                   .OrderByDescending(g => g.Value);

                var porDia = todas.Where(o => !string.IsNullOrEmpty(o.DataHora))
                                  .GroupBy(o => DateTime.Parse(o.DataHora).ToString("yyyy-MM-dd"))
                                  .ToDictionary(g => g.Key, g => g.Count());

                var pendentes = todas.Where(o => (o.Status ?? "pendente") == "pendente").Count();
                var resolvidas = todas.Where(o => (o.Status ?? "pendente") == "resolvida").Count();

                // Máquina mais crítica
                if (porMaquina.Any())
                {
                    var maqCritica = porMaquina.First();
                    LblMaquinaCritica.Text = maqCritica.Key;
                }
                else
                {
                    LblMaquinaCritica.Text = "-";
                }

                // Média diária
                double mediaDiaria = porDia.Count > 0 ? Math.Round((double)todas.Count / porDia.Count, 1) : 0;
                LblMediaDiaria.Text = mediaDiaria.ToString("0.0");

                // Tendência mensal
                var porMes = todas.Where(o => !string.IsNullOrEmpty(o.DataHora))
                                  .GroupBy(o => DateTime.Parse(o.DataHora).ToString("yyyy-MM"))
                                  .OrderBy(g => g.Key)
                                  .ToList();

                if (porMes.Count >= 2)
                {
                    var ultimo = porMes.Last().Count();
                    var anterior = porMes[porMes.Count - 2].Count();
                    var dif = ultimo - anterior;
                    var pct = anterior > 0 ? Math.Round((double)dif / anterior * 100, 1) : 0;
                    LblTendencia.Text = (dif >= 0 ? "+" : "") + pct + "%";
                }
                else
                {
                    LblTendencia.Text = "-";
                }

                // Erro mais comum
                if (porErro.Any())
                {
                    var erroComum = porErro.First();
                    LblErroComum.Text = erroComum.Key;
                }
                else
                {
                    LblErroComum.Text = "-";
                }

                // Pendentes
                LblPendentes.Text = pendentes.ToString();

                // Gráfico por mês
                GraficoMeses.Children.Clear();
                int max = porMes.Any() ? porMes.Max(g => g.Count()) : 1;

                foreach (var grupo in porMes)
                {
                    var barra = new BoxView
                    {
                        Color = Color.FromHex("#667eea"),
                        HeightRequest = 20,
                        WidthRequest = 50 + 200.0 * grupo.Count() / max,
                        HorizontalOptions = LayoutOptions.Start
                    };

                    GraficoMeses.Children.Add(new StackLayout
                    {
                        Orientation = StackOrientation.Horizontal,
                        Spacing = 10,
                        Children =
                        {
                            new Label { Text = grupo.Key, WidthRequest = 70, VerticalOptions = LayoutOptions.Center },
                            barra,
                            new Label { Text = grupo.Count().ToString(), VerticalOptions = LayoutOptions.Center }
                        }
                    });
                }

                // Lista de ocorrências
                ListaOcorrencias.ItemsSource = todas.Select(o => new
                {
                    Resumo = o.Resumo,
                    Descricao = o.Descricao,
                    Operador = o.OperadorNome ?? "-",
                    Status = o.StatusFormatado
                }).ToList();
            }
            catch (Exception ex)
            {
                await DisplayAlert("Erro", ex.Message, "OK");
            }
        }

        async void Atualizar_Clicked(object sender, EventArgs e)
        {
            await CarregarDados();
        }

        void Sair_Clicked(object sender, EventArgs e)
        {
            Sessao.Atual = null;
            Application.Current.MainPage = new NavigationPage(new LoginPage())
            {
                BarBackgroundColor = Color.FromHex("#1f3a5f"),
                BarTextColor = Color.White
            };
        }
    }
}

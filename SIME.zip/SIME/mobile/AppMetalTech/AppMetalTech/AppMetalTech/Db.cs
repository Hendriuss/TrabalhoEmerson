using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace AppMetalTech
{
    public static class Db
    {
        // URL da API - altere conforme seu servidor
        const string ApiUrl = "http://10.0.2.2/SIME/web/api.php?action=";

        static HttpClient client = new HttpClient { Timeout = TimeSpan.FromSeconds(30) };

        // Login estático para demonstração
        public static Usuario LoginStatico(string login, string senha)
        {
            if (login == "operador" && senha == "123")
            {
                return new Usuario
                {
                    Id = "1",
                    Nome = "João Operador",
                    Login = "operador",
                    Perfil = "operador"
                };
            }
            if (login == "supervisor" && senha == "123")
            {
                return new Usuario
                {
                    Id = "2",
                    Nome = "Maria Supervisor",
                    Login = "supervisor",
                    Perfil = "supervisor"
                };
            }
            return null;
        }

        static async Task<string> Post(string action, Dictionary<string, string> data)
        {
            try
            {
                var content = new FormUrlEncodedContent(data);
                var response = await client.PostAsync(ApiUrl + action, content);
                return await response.Content.ReadAsStringAsync();
            }
            catch
            {
                return null;
            }
        }

        static async Task<string> Get(string action)
        {
            try
            {
                var response = await client.GetAsync(ApiUrl + action);
                return await response.Content.ReadAsStringAsync();
            }
            catch
            {
                return null;
            }
        }

        public static async Task<List<Maquina>> Maquinas()
        {
            var json = await Get("maquinas");
            if (string.IsNullOrWhiteSpace(json))
                return new List<Maquina>
                {
                    new Maquina { Codigo = "tcnc01", Descricao = "Torno CNC 01" },
                    new Maquina { Codigo = "fcnc01", Descricao = "Fresadora CNC 01" },
                    new Maquina { Codigo = "cpr01", Descricao = "Cortadora Plasma 01" }
                };

            try
            {
                return JsonConvert.DeserializeObject<List<Maquina>>(json);
            }
            catch
            {
                return new List<Maquina>
                {
                    new Maquina { Codigo = "tcnc01", Descricao = "Torno CNC 01" },
                    new Maquina { Codigo = "fcnc01", Descricao = "Fresadora CNC 01" },
                    new Maquina { Codigo = "cpr01", Descricao = "Cortadora Plasma 01" }
                };
            }
        }

        public static async Task<List<Ocorrencia>> Ocorrencias()
        {
            var json = await Get("ocorrencias");
            if (string.IsNullOrWhiteSpace(json))
                return new List<Ocorrencia>();

            try
            {
                var array = JArray.Parse(json);
                var lista = new List<Ocorrencia>();
                foreach (var item in array)
                {
                    lista.Add(new Ocorrencia
                    {
                        Id = item["id"]?.ToString(),
                        MaquinaCodigo = item["maquina_codigo"]?.ToString(),
                        CodigoErro = item["codigo_erro"]?.ToString(),
                        Descricao = item["descricao"]?.ToString(),
                        DataHora = item["data_hora"]?.ToString(),
                        OperadorId = item["operador_id"]?.ToString(),
                        OperadorNome = item["operador"]?.ToString(),
                        Status = item["status"]?.ToString() ?? "pendente",
                        DataResolucao = item["data_resolucao"]?.ToString(),
                        ResolvidoPorNome = item["resolvido_por_nome"]?.ToString()
                    });
                }
                return lista;
            }
            catch
            {
                return new List<Ocorrencia>();
            }
        }

        public static async Task<List<Ocorrencia>> OcorrenciasDoOperador(int id)
        {
            var data = new Dictionary<string, string> { { "operador_id", id.ToString() } };
            var json = await Post("ocorrencias&filtro=operador", data);
            if (string.IsNullOrWhiteSpace(json))
                return new List<Ocorrencia>();

            try
            {
                var array = JArray.Parse(json);
                var lista = new List<Ocorrencia>();
                foreach (var item in array)
                {
                    lista.Add(new Ocorrencia
                    {
                        Id = item["id"]?.ToString(),
                        MaquinaCodigo = item["maquina_codigo"]?.ToString(),
                        CodigoErro = item["codigo_erro"]?.ToString(),
                        Descricao = item["descricao"]?.ToString(),
                        DataHora = item["data_hora"]?.ToString(),
                        OperadorId = item["operador_id"]?.ToString(),
                        Status = item["status"]?.ToString() ?? "pendente",
                        DataResolucao = item["data_resolucao"]?.ToString(),
                        ResolvidoPorNome = item["resolvido_por_nome"]?.ToString()
                    });
                }
                return lista;
            }
            catch
            {
                return new List<Ocorrencia>();
            }
        }

        public static async Task Registrar(Ocorrencia o)
        {
            var data = new Dictionary<string, string>
            {
                { "maquina", o.MaquinaCodigo },
                { "codigo_erro", o.CodigoErro },
                { "descricao", o.Descricao },
                { "operador_id", o.OperadorId }
            };
            await Post("registrar", data);
        }
    }
}

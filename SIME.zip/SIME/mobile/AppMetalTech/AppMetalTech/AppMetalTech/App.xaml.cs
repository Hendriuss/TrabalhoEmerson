using Xamarin.Forms;

namespace AppMetalTech
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
            MainPage = new NavigationPage(new LoginPage())
            {
                BarBackgroundColor = Color.FromHex("#1f3a5f"),
                BarTextColor = Color.White
            };
        }
    }
}

# SIME - Sistema de Monitoramento de Erros Industriais

Aplicativo mobile desenvolvido para a MetalTech Indústria Metalmecânica S.A. para registro e acompanhamento de falhas nas máquinas do chão de fábrica.

## Estrutura do Projeto

### Arquivos Principais

- **Models.cs**: Classes de dados (Usuario, Maquina, Ocorrencia) com campos de status e resolução
- **Db.cs**: Camada de acesso a dados com comunicação com API e login estático
- **App.xaml / App.xaml.cs**: Ponto de entrada da aplicação
- **LoginPage.xaml / LoginPage.xaml.cs**: Tela de login com design profissional
- **OperadorPage.xaml / OperadorPage.xaml.cs**: Tela do operador com KPIs e registro de ocorrências
- **SupervisorPage.xaml / SupervisorPage.xaml.cs**: Dashboard analítico com KPIs e gráficos

## Funcionalidades

### Login Estático
- **Operador**: login `operador`, senha `123`
- **Supervisor**: login `supervisor`, senha `123`

### Módulo do Operador
- **KPI Cards**: Total de registros, pendentes e resolvidos
- Registro rápido de ocorrências
- Seleção de máquina (tcnc01, fcnc01, cpr01)
- Código do erro e descrição detalhada
- Data/hora automática em tempo real
- Visualização dos últimos registros com status
- Interface inspirada no sistema web

### Módulo do Supervisor
- **6 KPI Cards**:
  - Total de ocorrências
  - Máquina mais crítica
  - Média diária de erros
  - Tendência mensal (%)
  - Erro mais comum
  - Ocorrências pendentes
- Gráfico de barras simples por mês
- Lista completa de ocorrências com filtros
- Interface inspirada no sistema web com Chart.js simplificado

## Design

- Cores corporativas (#1f3a5f, #ffd166, #e07a1f)
- Cards com bordas arredondadas e sombras
- Layout responsivo e scrollável
- Emojis como ícones para simplicidade
- KPIs coloridos com gradientes

## Configuração da API

A URL da API está configurada em `Db.cs`:
```csharp
const string ApiUrl = "http://10.0.2.2/SIME/web/api.php?action=";
```

Para uso em dispositivo físico, altere para o IP da sua máquina:
```csharp
const string ApiUrl = "http://192.168.1.X/SIME/web/api.php?action=";
```

## Requisitos

- Xamarin.Forms 5.0.0.2196
- Xamarin.Essentials 1.7.0
- Newtonsoft.Json 13.0.4
- .NET Standard 2.0

## Como Compilar

1. Abra a solução `AppMetalTech.sln` no Visual Studio
2. Selecione o projeto Android como startup
3. Compile e execute no emulador ou dispositivo

## Banco de Dados

O sistema integra com banco de dados MySQL através da API PHP localizada na pasta `web/`.

## Similaridade com Sistema Web

O mobile foi desenvolvido para espelhar a funcionalidade e design do sistema web:
- Mesmos KPIs e métricas
- Mesmo fluxo de trabalho
- Design visual similar
- Dados sincronizados via API

## Autores

Desenvolvido como protótipo para disciplina acadêmica.

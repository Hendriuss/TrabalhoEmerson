using System;
using System.Collections.Generic;
using System.Linq;
using Xamarin.Forms;

namespace SIME
{
    public class DashboardPage : ContentPage
    {
        StackLayout graficoMes = new StackLayout { Spacing = 6 };
        Picker pckMes = new Picker { Title = "Filtrar por mês" };
        Picker pckMaq = new Picker { Title = "Filtrar por máquina" };
        Label lblTotal = new Label { FontSize = 18, FontAttributes = FontAttributes.Bold };
        ListView lista = new ListView { HeightRequest = 350 };
        List<Ocorrencia> todas = new List<Ocorrencia>();

        public DashboardPage()
        {
            Title = "Dashboard: " + Sessao.Atual.Nome;
            var limpar = new Button { Text = "Limpar filtros" };
            limpar.Clicked += (s, e) => { pckMes.SelectedIndex = -1; pckMaq.SelectedIndex = -1; Filtrar(); };
            var atualizar = new Button { Text = "Atualizar", BackgroundColor = Color.FromHex("#1f3a5f"), TextColor = Color.White };
            atualizar.Clicked += async (s, e) => await Carregar();
            var sair = new Button { Text = "Sair" };
            sair.Clicked += (s, e) => { Sessao.Atual = null; Application.Current.MainPage = new NavigationPage(new LoginPage()); };
            pckMes.SelectedIndexChanged += (s, e) => Filtrar();
            pckMaq.SelectedIndexChanged += (s, e) => Filtrar();

            Content = new ScrollView
            {
                Content = new StackLayout
                {
                    Padding = 20, Spacing = 10,
                    Children =
                    {
                        lblTotal,
                        new Label { Text = "Erros por mês", FontAttributes = FontAttributes.Bold },
                        graficoMes,
                        new Label { Text = "Ocorrências", FontAttributes = FontAttributes.Bold, Margin = new Thickness(0,15,0,0) },
                        pckMes, pckMaq, limpar, lista, atualizar, sair
                    }
                }
            };
        }

        protected override async void OnAppearing() { base.OnAppearing(); await Carregar(); }

        async System.Threading.Tasks.Task Carregar()
        {
            try
            {
                todas = await Db.Ocorrencias();
                lblTotal.Text = "Total de ocorrências: " + todas.Count;

                var meses = todas.GroupBy(o => o.DataHora.ToLocalTime().ToString("yyyy-MM"))
                                 .OrderBy(g => g.Key).ToList();
                int max = meses.Any() ? meses.Max(g => g.Count()) : 1;
                graficoMes.Children.Clear();
                foreach (var g in meses)
                {
                    var barra = new BoxView { Color = Color.FromHex("#1f3a5f"), HeightRequest = 22,
                                              WidthRequest = 20 + 200.0 * g.Count() / max, HorizontalOptions = LayoutOptions.Start };
                    graficoMes.Children.Add(new StackLayout
                    {
                        Orientation = StackOrientation.Horizontal,
                        Children = { new Label { Text = g.Key, WidthRequest = 70, VerticalOptions = LayoutOptions.Center },
                                     barra, new Label { Text = g.Count().ToString(), VerticalOptions = LayoutOptions.Center } }
                    });
                }
                pckMes.ItemsSource = meses.Select(g => g.Key).ToList();
                pckMaq.ItemsSource = todas.Select(o => o.MaquinaCodigo).Distinct().OrderBy(x => x).ToList();
                Filtrar();
            }
            catch (Exception ex) { await DisplayAlert("Erro", ex.Message, "OK"); }
        }

        void Filtrar()
        {
            var r = todas.AsEnumerable();
            if (pckMes.SelectedIndex >= 0) { var m = (string)pckMes.SelectedItem; r = r.Where(o => o.DataHora.ToLocalTime().ToString("yyyy-MM") == m); }
            if (pckMaq.SelectedIndex >= 0) { var q = (string)pckMaq.SelectedItem; r = r.Where(o => o.MaquinaCodigo == q); }
            lista.ItemsSource = r.Select(o => o.Resumo + "\n" + o.Descricao).ToList();
        }
    }
}
